<!-- _coverpage.md -->

![logo](settings/xuhua1.png ':size=180')

# zwwen's Blog <small>1.0.0</small>

> 一个神奇的博客文档平台

- 记录日记（diary）
- 记录技术文档（tech log）
- other things

[日记](/diary)
[博客](https://github.com/docsifyjs/docsify/)
